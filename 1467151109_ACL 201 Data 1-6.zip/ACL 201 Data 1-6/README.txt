***********************************************************************************************
ACL201 Data Files Version 1-2
Release Date:???????????????????
***********************************************************************************************
Significant changes:
1. Removed the .AC file from case 4 to prevent the "Working Copy" message from appearing.

2. Updated the Excel working notes for each case study to reflect the re-wording of the analysis
   objectives. The order of some of the objectives have also changed but the solutions remain
   the same.

***********************************************************************************************
ACL201 Data Files Version 1-1
Release Date:Jun 23, 2014
***********************************************************************************************
Significant changes:
1.  Case 1 Dachery Stores - Combined the 4 general ledger text files for Asia Pacific, 
    Australsia, Europe and Middle East into one file named GL_Overseas.txt.

2.  Case 1 Dachery Stores - Changed Australasia to Australia in GL_Overseas.

3.  Case 1 Dachery Stores - Removed the creation of variables from the solution.

4.  Case 1 Dachery Stores - Removed the concatenation of last and first name for the final 
    report.

5.  Case 2 Skimpole Electronics - Project now exists named AP_Review2014.ACL to reflect that 
    import and preparation is already complete on the Employees, Payments, Receiving and 
    StandardPriceList tables. Working notes updated accordingly.

6.  Case 2 Skimpole Electronics - Changed objective 4b to calculate standard price variances
    for December only, not the full year.

7.  Case 2 Skimpole Electronics - Modified the steps for objective 4h by joining on two key 
    fields rather than relating on one. 

8.  Case 3 Steerforth Assistants - Project now exists named Pcard_Review2014.ACL to reflect that 
    import and preparation is already complete on all 4 tables. Working notes updated accordingly.

9.  Case 3 Steerforth Assistants - Steps in working notes for objective 4g (split purchases) has
    been updated to simplify and correct errors. 

10. Case 4 Dedlock Security - Project now exists named TNE_Expenses.ACL to reflect that import 
    and preparation is already complete on the Employees, ExpenseTypes and TravelPreauth tables. 
    Working notes updated accordingly.

11. Case 4 Dedlock Security - Objectives 4a and 4b have been reversed.

12. Case 5 Nadgett Inc - The objectives remain the same but their order and wording have been 
    modified.

***********************************************************************************************
ACL201 Data Files Version 1-2
Release Date:Sep 16, 2014
***********************************************************************************************
Significant changes:
1. Updates to Excel working notes to reflect updates to the ACL201 training manual. 

***********************************************************************************************
ACL201 Data Files Version 1-2
Release Date:Feb 01, 2015
***********************************************************************************************
Significant changes:
1. The case study projects were updated to Version 11.
2. The "Analysis Objectives" columns in the Excel working notes were updated to reflect those
   in the manual. 